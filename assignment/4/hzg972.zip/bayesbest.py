# Name: He Zhao, Xiaolin Li, Zijiang Yang
# netID: hzg972, xlo365, zyz293
# Date: May 21, 2015
# Filename: bayesbest.py
# Description: improved naive bayes classifier
# This improved classifier uses bigrams as elements in training and testing. 
# It removes all punctuation except for exclamation mark in making the pickle dictionaries. 

import math, os, pickle, re, random, copy, operator

class Bayes_Classifier:

   def __init__(self, lTrainFiles = [], fpicklePos = 'dPosBigramImproved', fpickleNeg = 'dNegBigramImproved'):
      """This method initializes and trains the Naive Bayes Sentiment Classifier.  If a 
      cache of a trained classifier has been stored, it loads this cache.  Otherwise, 
      the system will proceed through training.  After running this method, the classifier 
      is ready to classify input text."""

      self.dPos = {}
      self.dNeg = {}
      fdPos = fpicklePos
      fdNeg = fpickleNeg 
      if os.path.isfile(fdPos) and os.path.isfile(fdNeg) :
         self.dPos = Bayes_Classifier.load(self, fdPos)
         self.dNeg = Bayes_Classifier.load(self, fdNeg)
      else:
         Bayes_Classifier.train(self, lTrainFiles, outPos = fpicklePos, outNeg = fpickleNeg)

   def train(self, lFileList = [], outPos = 'dPosBigramImproved', outNeg = 'dNegBigramImproved'):   
      """Trains the Naive Bayes Sentiment Classifier. Improved: using bigrams"""
      dPos = {}
      dNeg = {}
      if lFileList == []: # train entire model if lFilelist is empty
         for fFileObj in os.walk("reviews/"):
            lFileList = fFileObj[2] 
            break
      ct = 0
      # print 'Start training model ... '
      for fn in lFileList:
         ct += 1
         # print ct
         text = Bayes_Classifier.loadFile(self, "reviews/"+fn)
         words = Bayes_Classifier.tokenize(self,text)
         if fn[7] == '5': # positive movie review
            for i in range(len(words)-1):
               word = words[i]+' '+words[i+1] # bigram
               if words[i] != '.' and words[i] != ',' and words[i] != "'" and words[i] != '?' and words[i] != '(' and words[i] != ')' and words[i+1] != '.' and words[i+1] != ',' and words[i+1] != "'" and words[i+1] != '?' and words[i+1] != '(' and words[i+1] != ')':                        
                  if word in dPos:
                     freq = dPos[word] 
                     dPos[word] = freq + 1
                  else:
                     dPos[word] = 1
         elif fn[7] == '1': # negative movie review
            for i in range(len(words)-1):
               word = words[i]+' '+words[i+1] # bigram
               if words[i] != '.' and words[i] != ',' and words[i] != "'" and words[i] != '?' and words[i] != '(' and words[i] != ')' and words[i+1] != '.' and words[i+1] != ',' and words[i+1] != "'" and words[i+1] != '?' and words[i+1] != '(' and words[i+1] != ')':                        
                  if word in dNeg:
                     freq = dNeg[word] 
                     dNeg[word] = freq + 1
                  else:
                     dNeg[word] = 1
      # print 'Size of training data: ', ct                     

      # Remove emotionless bigrams
      dNewPos = {}
      dNewNeg = {}
      totalpos = 0
      for w, f in dPos.items():
         totalpos += f
      totalneg = 0
      for w, f in dNeg.items():
         totalneg += f
      ratio = float(float(totalpos)/float(totalneg))
      for w, f in dPos.items():
         dNewPos[w] = f
      for w, f in dNeg.items():
         dNewNeg[w] = f * ratio   
      # print 'total pos bigram: ', totalpos
      # print 'total neg bigram: ', totalneg
      # print 'freq ratio: pos/neg:, ', ratio
      for wp, fp in dNewPos.items():
         if wp in dNewNeg:
            fn = dNewNeg[wp]
            dif = abs((float(fp)-float(fn))/max(float(fp), float(fn)))
            if dif < float(0.2):
               del dNewNeg[wp]
               del dNewPos[wp]
      totalpos = 0
      for w, f in dNewPos.items():
         totalpos += f
      totalneg = 0
      for w, f in dNewNeg.items():
         totalneg += f
      # print 'after deleting redundant emotionless bigrams: '
      # print 'total pos bigram: ', totalpos
      # print 'total neg bigram: ', totalneg
      self.dPos = dNewPos
      self.dNeg = dNewNeg
      Bayes_Classifier.save(self, dNewPos, outPos) # write resultant dict to file
      Bayes_Classifier.save(self, dNewNeg, outNeg)

   def classify(self, sText):
      """Given a target string sText, this function returns the most likely document
      class to which the target string belongs (i.e., positive, negative or neutral).
      """
      # calculate total counts as sum of frequencies for pos and neg
      totalpos = 0
      for w, f in self.dPos.items():
         totalpos += f
      totalneg = 0
      for w, f in self.dNeg.items():
         totalneg += f
      words = Bayes_Classifier.tokenize(self,sText)
      # Positive
      bSmooth = False
      SmoothAdd = 0 
      dCurdictPos = {}
      for i in range(len(words)-1):
         word = words[i]+' '+words[i+1] # bigram
         if word in dCurdictPos and dCurdictPos[word] != 0: # if the bigram already exists 
            freq = dCurdictPos[word]
            dCurdictPos[word] = freq + self.dPos[word]
         elif word in self.dPos: # first time appearance
            dCurdictPos[word] = self.dPos[word]
         else: 
            bSmooth = True
            SmoothAdd += 1
            dCurdictPos[word] = 0            
      pfpos = 0 # initialize probability of positive document
      for w, f in dCurdictPos.items():
         if bSmooth == False:
            pfpos += math.log10(float(f)/float(totalpos))
         else:
            pfpos += math.log10(float(f+1)/float(totalpos+SmoothAdd))
      # Negative
      dCurdictNeg = {}
      bSmooth = False
      SmoothAdd = 0 
      for i in range(len(words)-1):
         word = words[i]+' '+words[i+1] # bigram
         if word in dCurdictNeg and dCurdictNeg[word] != 0: # if the bigram already exists 
            freq = dCurdictNeg[word]
            dCurdictNeg[word] = freq + self.dNeg[word]
         elif word in self.dNeg: # first time appearance
            dCurdictNeg[word] = self.dNeg[word]
         else: 
            bSmooth = True
            SmoothAdd += 1
            dCurdictNeg[word] = 0  
      pfneg = 0 # initialize probability of document as positive
      for w, f in dCurdictNeg.items():
         if bSmooth == False:
            pfneg += math.log10(float(f)/float(totalneg))
         else:
            pfneg += math.log10(float(f+1)/float(totalneg+SmoothAdd))
      # print pfpos
      # print pfneg
      # print dCurdictPos
      # print dCurdictNeg
      Pcutoff = 0 # cutoff probability difference to determine on neutral 
      if pfpos - pfneg > Pcutoff: # P(positive) two order of magnitude larger than P(negative)
         sSentiment = 'positive'
      elif pfneg - pfpos > Pcutoff:
         sSentiment = 'negative'
      else:
         sSentiment = 'neutral'
      return sSentiment

   def loadFile(self, sFilename):
      """Given a file name, return the contents of the file as a string."""

      f = open(sFilename, "r")
      sTxt = f.read()
      f.close()
      return sTxt
   
   def save(self, dObj, sFilename):
      """Given an object and a file name, write the object to the file using pickle."""

      f = open(sFilename, "w")
      p = pickle.Pickler(f)
      p.dump(dObj)
      f.close()
   
   def load(self, sFilename):
      """Given a file name, load and return the object stored in the file."""

      f = open(sFilename, "r")
      u = pickle.Unpickler(f)
      dObj = u.load()
      f.close()
      return dObj

   def tokenize(self, sText): 
      """Given a string of text sText, returns a list of the individual tokens that 
      occur in that string (in order)."""

      lTokens = []
      sToken = ""
      for c in sText:
         if re.match("[a-zA-Z0-9]", str(c)) != None or c == "\"" or c == "_" or c == "-":
            sToken += c
         else:
            if sToken != "":
               lTokens.append(sToken)
               sToken = ""
            if c.strip() != "":
               lTokens.append(str(c.strip()))
               
      if sToken != "":
         lTokens.append(sToken)

      return lTokens

   def crossValidate(self, k = 10):
      '''k-fold cross validation to calculate precision, recall and F1 measure of the trained model. Default k = 10'''
      
      lFileList = []
      for fFileObj in os.walk("reviews/"):
         lFileList = fFileObj[2] 
         break
      iTestDataNum = math.floor(float(len(lFileList))/float(float(k)))
      numTestSet = len(lFileList)/int(iTestDataNum)
      lFilesRemained = range(1, len(lFileList))
      lFilesAll = copy.deepcopy(lFilesRemained)
      # print 'Total size of entire dataset:, ', len(lFilesRemained)
      lTestDataIndex=[]
      for i in range(numTestSet):
         if int(iTestDataNum) <= len(lFilesRemained):
            lTestDataIndex.append(random.sample(lFilesRemained, int(iTestDataNum))) # Get indices for random one k-th of the entire dataset
            lFilesRemained= list(set(lFilesRemained) - set(lTestDataIndex[i]))
         elif int(iTestDataNum) > len(lFilesRemained):
            lTestDataIndex.append(lFilesRemained)
      # Initalize cross validation measures
      lCVaccuracy = []
      lCVPosPrecision = []
      lCVNegPrecision= []
      lCVPosRecall= []
      lCVNegRecall= []
      lCVPosF1= []
      lCVNegF1= []
      for ii in range(numTestSet): # for each k-th fold
         lTrainDataIndex = list(set(lFilesAll) - set(lTestDataIndex[ii]))
         lTrainData = []
         for j in lTrainDataIndex:
            lTrainData.append(lFileList[j])
         # remove CV pickled files if exist
         f10foldCVPositive = 'dPos10fCVtest'
         f10foldCVNegative = 'dNeg10fCVtest'
         if os.path.exists(f10foldCVPositive):
            os.remove(f10foldCVPositive)
         if os.path.exists(f10foldCVNegative):
            os.remove(f10foldCVNegative)  
         # initialize and train to save to CV pickle files 
         Bayes_Classifier.train(self, lTrainData, f10foldCVPositive, f10foldCVNegative)
         iMatchCount = 0 # Number of predictions that match with real sentiment
         iTruePosCount = 0 # Real positive
         iTrueNegCount = 0 # Real positive
         iPredictPos = 0 # Predicted positive
         iPredictNeg = 0 # Predicted negative
         iPredictTruePos = 0 # True predicted positive
         iPredictTrueNeg = 0 # True predicted negative
         testct = 0 
         for i in lTestDataIndex[ii]:
            fn = lFileList[i] 
            text = bc.loadFile("reviews/"+fn)
            if fn[7] == '5': # positive movie review
               sTruesentiment = 'positive'
               iTruePosCount += 1
            elif fn[7] == '1':
               sTruesentiment = 'negative'
               iTrueNegCount += 1
            sPredictedsentiment = Bayes_Classifier.classify(self, text)
            if sPredictedsentiment == 'positive':
               iPredictPos += 1
            elif sPredictedsentiment == 'negative':
               iPredictNeg += 1
            if sPredictedsentiment == sTruesentiment:
               iMatchCount += 1
               if sPredictedsentiment == 'positive':
                  iPredictTruePos += 1
               elif sPredictedsentiment == 'negative':
                  iPredictTrueNeg += 1
            testct += 1
         fAccuracy = float(float(iMatchCount)/float(len(lTestDataIndex[ii])))    
         fPosPrecision = float(float(iPredictTruePos)/float(iTruePosCount))
         fNegPrecision = float(float(iPredictTrueNeg)/float(iTrueNegCount))
         fPosRecall = float(float(iPredictTruePos)/float(iPredictPos))
         fNegRecall = float(float(iPredictTrueNeg)/float(iPredictNeg))
         fPosF1 = float(float(2)*fPosPrecision*fPosRecall/(fPosPrecision+fPosRecall))
         fNegF1 = float(float(2)*fNegPrecision*fNegRecall/(fNegPrecision+fNegRecall))
         lCVaccuracy.append(fAccuracy)
         lCVPosPrecision.append(fPosPrecision)
         lCVNegPrecision.append(fNegPrecision)
         lCVPosRecall.append(fPosRecall)
         lCVNegRecall.append(fNegRecall)
         lCVPosF1.append(fPosF1)
         lCVNegF1.append(fNegF1)
      print 'average accuracy from CV: ', sum(lCVaccuracy)/float(len(lCVaccuracy))
      print 'average POS precision from CV: ', sum(lCVPosPrecision)/float(len(lCVPosPrecision))
      print 'average NEG precision from CV: ', sum(lCVNegPrecision)/float(len(lCVNegPrecision))
      print 'average POS recall from CV: ', sum(lCVPosRecall)/float(len(lCVPosRecall))
      print 'average NEG recall from CV: ', sum(lCVNegRecall)/float(len(lCVNegRecall))
      print 'average POS F1 from CV: ', sum(lCVPosF1)/float(len(lCVPosF1))
      print 'average NEG F1 from CV: ', sum(lCVNegF1)/float(len(lCVNegF1))         

   def rankHotWords(self, ctlim = 50):
      '''Display top 50 hot words in pickled dictionary'''

      sorted_dPos = sorted(self.dPos.items(), key=operator.itemgetter(1))
      sorted_dPos.reverse()
      sorted_dNeg = sorted(self.dNeg.items(), key=operator.itemgetter(1))
      sorted_dNeg.reverse()
      ct = 0 
      for word, freq in sorted_dPos: 
         print 'Positive Word %s has a frequency of %i' % (word, freq)
         ct += 1
         if ct >= ctlim:
               break
      ct = 0         
      for word, freq in sorted_dNeg: 
         print 'Negative Word %s has a frequency of %i' % (word, freq)
         ct += 1
         if ct >= ctlim:
               break